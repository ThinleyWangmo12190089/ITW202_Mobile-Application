package com.example.todo_3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class SecondMainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_main);
    }
}